	/* 
		Local Storage contains:
			form: firstName --> fname
			form: lastName --> lname
			form: Email --> cemail
			form: Phone Number --> pNum
	*/	
	
	
$(document).ready(function() {			

	$("#addContact").click(function() {
		fname = $("#firstName").val();		// if name and id set
		
		$b = $("input[name='lastName']");	// if name set but not id
		lname = $b.val();
		
		$b = $("input[name='email']");
		cemail = $b.val();
		
		$b = $("input[name='number']");
		pNum = $b.val();
		
		localStorage.setItem("fname", fname);
		localStorage.setItem("lname", lname);
		localStorage.setItem("cemail", cemail);
		localStorage.setItem("pNum", pNum);
		
		} 
		alert("Contact Save in Diretory");
	});


	$("#viewContact").click(function() {
		// pulling items individually
		head = "Contacts: <br>";
		FirstName = localStorage.getItem("fname") + "<br>";
		LastName = localStorage.getItem("lname") + "<br>";
		Email = localStorage.getItem("cemail") + "<br>";
		PhoneNumber = localStorage.getItem("pNum") + "<br>";
		
		fileLength = localStorage.length + " profile items";
		profile = head + FirstName + LastName + Email + PhoneNumber + fileLength;
		
		$("#contactInfo").html(profile);
		$("#contactInfo").append("<br><br>");

		// pulling items using a loop ... notice order
		for (i=0; i<localStorage.length; i++) {
			key = localStorage.key(i);
			val = localStorage.getItem(key);
			$("#contactInfo").append(val + "<br>");
			console.log(key);
			console.log(val);
		} 
		
		
		
	
		
		// include localstorage in id's

		
	});  // end of retrieve



	$("#deleteContact").click(function() {
		console.log("in clear");
		//localStorage.removeItem("fname"+"lname");
		localStorage.clear();
		alert("Contact Deleted");
		
	}); // end of clear
});	